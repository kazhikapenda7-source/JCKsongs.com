// Profile picture upload
document.getElementById('upload-profile-pic-button').addEventListener('click', () => {
    const profilePicInput = document.getElementById('profile-pic-input');
    const profilePic = document.getElementById('profile-pic');
    const file = profilePicInput.files[0];
// Bio
document.getElementById('save-bio-button').addEventListener('click', () => {
    const bioTextarea = document.getElementById('bio-textarea');
    const bioDisplay = document.getElementById('bio-display');
    bioDisplay.innerText = bioTextarea.value;
});

// Music Player
const musicPlayerAudio = document.getElementById('music-player-audio');
const playMusicButton = document.getElementById('play-music-button');
const pauseMusicButton = document.getElementById('pause-music-button');

playMusicButton.addEventListener('click', () => {
    musicPlayerAudio.play();
});

pauseMusicButton.addEventListener('click', () => {
    musicPlayerAudio.pause();
});

// Upload music and play
document.getElementById('upload-music-button').addEventListener('click', () => {
    const musicFileInput = document.getElementById('music-file');
    const file = musicFileInput.files[0];
    const reader = new FileReader();
    reader.onload = () => {
        musicPlayerAudio.src = reader.result;
        musicPlayerAudio.play();
    };
    reader.readAsDataURL(file);
});